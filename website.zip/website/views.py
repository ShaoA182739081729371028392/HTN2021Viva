from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect
import json
import base64
import os
import numpy as np
from io import BytesIO
from pydub import AudioSegment
import sys
from . import cockroach_db
from . import TTS
from . import STT
import os 
from django import forms
from django.core.mail import send_mail
import smtplib, ssl
ssl._create_default_https_context = ssl._create_unverified_context
from django.conf import settings
from dotenv import load_dotenv
# Create your views here.

DATABASES = {}

def index(request):
    if 'Username' not in request:
        request.session['Username'] = None
        request.session['Signed_In'] = False
    return render(request, "index.html", {})


def signup(request):
    # check if already logged in, in which the user is kinda stupid
    if request.session['Signed_In']:
        return redirect('/')
    
    return render(request, "signup.html", {}) 

def profile(request):
    return render(request, "profile.html", {})

def gym(request):
    return render(request, "gym.html", {})

def learn(request):
    return render(request, "learn.html", {})
def dashboard(request):
    #if request.session['Signed_In']:
    return render(request, "dashboard.html", {})
    #return redirect('/dashboard')
@csrf_exempt
def get_username(request):
    return JsonResponse({'username': request.session['username']})
@csrf_exempt
def flash(request):
    return render(request, 'flash.html', {})

@csrf_exempt
def check_cookie(request):
    #if request.session['Signed_In']:
    return JsonResponse({"page": "logged_in"})
    #return JsonResponse({"page": "not_logged_in"})
    
@csrf_exempt
def check_speech(request):
    import json
    data = json.loads(request.body.decode("utf-8"))['data']
    print(json.loads(request.body.decode("utf-8")))
    ground_truth = json.loads(request.body.decode('utf-8'))['ground_truth']
    # make a TTS file 
    audio_TTS = TTS.output_speech(ground_truth)

    # Remove the base64 text before
    data = data.split(',')[1]
    data = data.split("\"")[0]

    data = base64.b64decode(data) 
    
    loaded = BytesIO(data)
    loaded = AudioSegment.from_file(loaded) 

    export = BytesIO()
    export = loaded.export(export, format = 'wav', parameters=['-acodec', 'pcm_s16le'])
    export = export.read()

    response = None
    for x in STT.process(export):
        response = x
        break
    if response == None:
        score = 0 
        return JsonResponse({'transcript':  "", 'ground_truth':  json.loads(request.body.decode('utf-8'))['ground_truth'],  'TTS': str(audio_TTS), 'score': score})
    else:
       
        transcript = response.alternatives[0].transcript
        confidence = response.alternatives[0].confidence
    # Compute the Overall Grade 
        transcript = set(transcript.split() )
        ground_truth = set(ground_truth.split())
        intersected = transcript.intersection(ground_truth)
        union = transcript.union(ground_truth)

        iou = len(intersected) / len(union)
        score = (iou + confidence) / 2 # 0 -> 1


        return JsonResponse({'transcript':  response.alternatives[0].transcript, 'ground_truth':  json.loads(request.body.decode('utf-8'))['ground_truth'],  'TTS': str(audio_TTS), 'score': score})

@csrf_exempt
def submit_signup_or_login(request):
    #if request.session['Signed_In']:
    #    return JsonResponse({'page': 'logged_in'})
    #if 'data[username]' not in request.POST:
        # Render the signup page 
    #    return redirect("/dashboard")
    
    Username = request.POST['data[username]']
    Password = request.POST['data[password]']
    if Username == "" or Password == '':
        return JsonResponse({'page': 'empty_credentials'})
    Submission_Type = request.POST['data[type]']

    if Submission_Type == 'LogIn':
        # Log the User In
        if submit_login (request, Username, Password):
            return JsonResponse({"page": "logged_in"})
        return JsonResponse({"page": "incorrect_credentials"})
    else:
        # Sign up the User
        if submit_signup(request, Username, Password):
            return JsonResponse({'page': 'logged_in'})
        return JsonResponse({'page': 'user_exists'})
def submit_signup(request, Username, Password):
    if cockroach_db.personExists(Username):
        return False
    cockroach_db.InsertClient(Username, Password)
    request.session['Signed_In'] = True
    request.session['Username'] = Username
    
    return True 

def submit_login(request, Username, Password):
    # Check Credentials
    if cockroach_db.getPerson(Username, Password):
        # Then, sign in and cache results in cookies
        request.session['Signed_In'] = True
        request.session['Username'] = Username
        return True
    else:
        request.session['Signed_In'] = False
        request.session['Username'] = None
        return False 

