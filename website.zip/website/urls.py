from django.contrib import admin
from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.index, name = 'index'),
    path('check_speech', views.check_speech, name = 'check_speech'),
    path("get_username", views.get_username, name = 'get_username'),
    path('flash', views.flash, name = 'flash'),
    path('dashboard', views.submit_signup_or_login, name = 'dashboard'),
    path('check_cookie', views.check_cookie, name = "check_cookie"), 
    path('user', views.dashboard, name = 'user'), # Weird naming, but I have variable name confloicts
    path('signup', views.signup, name = 'signup'),
    path('profile', views.profile, name = 'profile'),
    path('gym', views.gym, name = 'gym'),
    path('learn', views.learn, name = 'learn')
]