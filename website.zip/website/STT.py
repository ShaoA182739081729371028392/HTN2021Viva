# Basic Speech to Text Testing
 
import time 
import wave
from google.cloud import speech
from google.cloud import speech_v1
from google.cloud import storage  
import io
from google.oauth2 import service_account 
def process(content):
    audio = speech.RecognitionAudio(content=content)
    
    path = "/Users/andrewshao/Desktop/viva/viva-325014-93d47788916a.json"
    creds = service_account.Credentials.from_service_account_file(path) 
    speech_client = speech_v1.SpeechClient(credentials=creds)
    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=48000,
        language_code="en-US",
    )

    
    response = speech_client.recognize(config=config, audio=audio)
    return response.results
