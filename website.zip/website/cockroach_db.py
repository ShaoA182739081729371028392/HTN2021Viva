
#!/usr/bin/env python3
'''
HANDLES all logic related to Cockroach DB, using Python

'''
opt = 'postgresql://shaoa182739081729371:Viva12345678@free-tier.gcp-us-central1.cockroachlabs.cloud:26257/defaultdb?sslmode=verify-full&sslrootcert=/Users/andrewshao/.postgresql/root.crt&options=--cluster%3Dsuper-deer-3433'

import time
import random
import logging
from argparse import ArgumentParser, RawTextHelpFormatter

import psycopg2
from psycopg2.errors import SerializationFailure


def create_accounts():
    conn = psycopg2.connect(opt)
    with conn.cursor() as cur:
        cur.execute(
            "CREATE TABLE IF NOT EXISTS accounts (username TEXT, password TEXT, progress INT);"
        )
        # Progress is just an integer, marking the percent of progress of the given user.

    conn.commit()
    conn.close()
def updateProgress(username, new_progress):
    conn = psycopg2.connect(opt)
    if not personExists(conn, username):
        return False
    with conn.cursor() as cur:
        cur.execute("UPDATE accounts SET progress = %s WHERE username = %s", (new_progress, username))
    conn.commit()
    conn.close()



def InsertClient(username, password):
    # First check if it exists
    if personExists(username):
        return False 
    conn = psycopg2.connect(opt)
    
    with conn.cursor() as cur:
        cur.execute("INSERT INTO accounts VALUES (%s, %s, 0)", (username, password))
    conn.commit()
    conn.close()
    return True 



def personExists(username):
    conn = psycopg2.connect(opt)
    with conn.cursor() as cur:
        cur.execute("SELECT progress FROM accounts WHERE username = %s", (username, ))
        values = cur.fetchone()
      
    conn.close()
    return values != None 
def getPerson(username, password):
    conn = psycopg2.connect(opt)
    # checks whether or not a given username and password are in the relational database.
    with conn.cursor() as cur:
        cur.execute("SELECT progress FROM accounts WHERE username = %s AND password = %s", (username, password))
        values = cur.fetchone()
    conn.close()
    return values


def test_retry_loop(conn):
    """
    Cause a seralization error in the connection.

    This function can be used to test retry logic.
    """
    with conn.cursor() as cur:
        # The first statement in a transaction can be retried transparently on
        # the server, so we need to add a dummy statement so that our
        # force_retry() statement isn't the first one.
        cur.execute("SELECT now()")
        cur.execute("SELECT crdb_internal.force_retry('1s'::INTERVAL)")
    logging.debug("test_retry_loop(): status message: %s", cur.statusmessage)