This repo contains the source code for a simple Django application, written in Python.

For instructions on starting CockroachDB and running the code, see [this tutorial](https://www.cockroachlabs.com/docs/stable/build-a-python-app-with-cockroachdb-django.html).
